import smtplib
import os
import json
import re
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, SMTP_SERVER, RESUME_PATH

# Ollama API URL
OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

SKIPPED_EMAILS = "skipped_emails.json"

NEGOTIATE_THRESHOLD = 85
MIN_ACCEPTABLE_RATE = 75
HOURS_PER_YEAR = 2080

def clean_html(raw_html):
    """Remove HTML tags and extract plain text from an email body."""
    clean_text = re.sub(r'<.*?>', '', raw_html)
    return clean_text.strip()

def check_subject_first(email_subject):
    """Determine if the email subject is job-related using the Mistral model via Ollama."""
    prompt = f"""
    Determine if the following email **subject line** is likely to be from a recruiter about a job opportunity.

    Subject: {email_subject}

    Respond with JSON:
    {{
        "job_related": true or false
    }}
    """

    try:
        response = requests.post(OLLAMA_URL, json={"model": "mistral", "prompt": prompt})
        result = response.json().get("response", "{}")
        extracted_data = json.loads(result)
        return extracted_data.get("job_related", False)
    except Exception as e:
        print(f"⚠️ Failed to analyze subject with Ollama: {e}")
        return None

def extract_rate_location(email_subject, email_body):
    """Extract pay rate and job location using Ollama."""
    cleaned_body = clean_html(email_body)

    prompt = f"""
    Analyze the following email content and subject.

    1. Determine if this is a job opportunity email from a **tech recruiter**.
    2. Extract the **pay rate** (in USD per hour) and **job location**.
    3. If the email asks for a resume, classify it as job-related.

    Subject: {email_subject}
    Full Email Content:
    {cleaned_body}

    Ensure the response is a **JSON object** formatted like this:
    {{
        "rate": "XX",
        "location": "Remote" or "City, State" or "On-Site" or "Unknown",
        "not_related": true or false
    }}
    """

    try:
        response = requests.post(OLLAMA_URL, json={"model": "mistral", "prompt": prompt})
        result = response.json().get("response", "{}")
        extracted_data = json.loads(result)

        if extracted_data.get("not_related", False):
            return "Not Related", "Not Related"

        rate = extracted_data.get("rate", "Unknown")
        location = extracted_data.get("location", "Unknown")

        return rate, location
    except Exception as e:
        print(f"❌ Failed to extract rate/location: {e}")
        return "Unknown", "Unknown"

def generate_response(email_subject, email_body, sender):
    """Generate an AI response for a recruiter email using Ollama."""
    prompt = f"""
    Read the following **job-related email** and generate a polite, professional response.

    Subject: {email_subject}
    Sender: {sender}
    Email Content:
    {clean_html(email_body)}

    Respond with an **appropriate reply** formatted as an email response.
    """

    try:
        response = requests.post(OLLAMA_URL, json={"model": "mistral", "prompt": prompt})
        result = response.json().get("response", "Error generating response.")
        return result
    except Exception as e:
        print(f"❌ Error generating response: {e}")
        return "Error generating response."

def send_email(recipient_email, subject, body):
    """Send an email response to a recruiter."""
    try:
        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = recipient_email
        msg["Subject"] = subject

        msg.attach(MIMEText(body, "plain"))

        if RESUME_PATH and os.path.exists(RESUME_PATH):
            with open(RESUME_PATH, "rb") as attachment:
                resume = MIMEText(attachment.read(), "base64", "utf-8")
                resume.add_header("Content-Disposition", "attachment", filename=os.path.basename(RESUME_PATH))
                msg.attach(resume)

        with smtplib.SMTP_SSL(SMTP_SERVER, 465) as server:
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.sendmail(EMAIL_ADDRESS, recipient_email, msg.as_string())

        print(f"📧 Email sent successfully to {recipient_email}")

    except Exception as e:
        print(f"❌ Error sending email: {e}")
